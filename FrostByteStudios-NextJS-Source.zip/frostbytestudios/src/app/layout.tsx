import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FrostByteStudios — Turning Ideas Into Digital Reality",
  description:
    "FrostByteStudios by Aerix builds custom bots, websites, applications, Minecraft experiences, launchers, and hosting infrastructure.",
  applicationName: "FrostByteStudios",
  keywords: [
    "FrostByteStudios",
    "Aerix",
    "web development",
    "Discord bots",
    "Minecraft server development",
    "hosting setup",
  ],
  openGraph: {
    title: "FrostByteStudios — Engineering Tomorrow, Today",
    description:
      "Your vision. Our code. Limitless possibilities. Explore development services by Aerix.",
    type: "website",
  },
  icons: { icon: "/favicon.svg" },
};

export const viewport: Viewport = {
  themeColor: "#070b12",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
