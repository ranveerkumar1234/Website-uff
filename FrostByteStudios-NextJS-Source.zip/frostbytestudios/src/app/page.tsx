"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowDownRight, ArrowRight, Bot, Braces, Check, ChevronDown, Code2,
  Cpu, ExternalLink, Globe2, Layers3, Mail, MapPin, Menu, Moon,
  MonitorCog, Package, Send, Server, ShieldCheck, Snowflake, Sparkles,
  Sun, TerminalSquare, Workflow, X, Zap,
} from "lucide-react";

type ProjectCategory = "Bots" | "Websites" | "Applications" | "Minecraft" | "Launchers" | "Hosting";
type Project = {
  name: string;
  category: ProjectCategory;
  description: string;
  technologies: string[];
  status: "Concept" | "In Progress" | "Completed";
  icon: typeof Bot;
};

const services = [
  { number: "01", title: "Custom Bots", icon: Bot, description: "Useful bots built around your workflow—from Discord community tools and moderation to automation and custom utilities." },
  { number: "02", title: "Website Development", icon: Globe2, description: "Responsive, modern websites for portfolios, businesses, gaming communities, dashboards, and web-based ideas." },
  { number: "03", title: "Application Development", icon: Layers3, description: "Purpose-built tools and applications shaped around your requirements, platform, and intended users." },
  { number: "04", title: "Minecraft Servers", icon: Cpu, description: "Custom server setup for SMP, Lifesteal, Survival, PvP, minigames, plugins, permissions, and configuration." },
  { number: "05", title: "Minecraft Launchers", icon: MonitorCog, description: "A branded launcher concept with a custom interface and planned version, profile, and mod-management features." },
  { number: "06", title: "Hosting & Infrastructure", icon: Server, description: "Deployment and setup for game servers, bots, websites, panels, and other hosting infrastructure." },
];

const projects: Project[] = [
  { name: "Community Bot System", category: "Bots", description: "A concept for a configurable community bot with moderation, utilities, and server management modules.", technologies: ["Python", "Discord API"], status: "Concept", icon: Bot },
  { name: "Studio Portfolio", category: "Websites", description: "A responsive studio website concept with project discovery, service information, and a contact workflow.", technologies: ["Next.js", "TypeScript"], status: "In Progress", icon: Globe2 },
  { name: "Minecraft Network", category: "Minecraft", description: "A flexible Minecraft network concept with server configuration, permissions, and a player-friendly lobby.", technologies: ["Paper", "Java"], status: "Concept", icon: TerminalSquare },
  { name: "Launcher UI Concept", category: "Launchers", description: "A branded launcher interface concept designed around profiles, versions, and modded gameplay.", technologies: ["TypeScript", "UI Design"], status: "Concept", icon: MonitorCog },
  { name: "Hosting Dashboard", category: "Hosting", description: "A hosting dashboard concept for organizing services, server status, and deployment information.", technologies: ["React", "Node.js"], status: "Concept", icon: Server },
  { name: "Utility App", category: "Applications", description: "A small utility application concept focused on a clear interface and a simple task-focused workflow.", technologies: ["React", "TypeScript"], status: "Concept", icon: Package },
];

const faqs = [
  { q: "What services does FrostByteStudios offer?", a: "I work on custom bots, websites, applications, Minecraft servers, custom launcher concepts, and hosting setup. The exact scope depends on your requirements and technical feasibility." },
  { q: "Can I request a completely custom project?", a: "Yes. Use the contact form and choose “Custom Project.” Explain the idea, what you want it to do, and any requirements you already have. We can discuss a practical approach." },
  { q: "How do I start a project?", a: "Send a project inquiry with your contact details, a short description, desired features, and any budget or deadline you have in mind. I'll use that information to discuss next steps." },
  { q: "How much does development cost?", a: "Pricing depends on scope, complexity, integrations, and delivery requirements. A price should be agreed on after the project details are discussed; this site does not promise a fixed price." },
  { q: "How long will my project take?", a: "Timelines depend on the features, complexity, testing, and any third-party requirements. A realistic timeline can be discussed after the project scope is clear." },
  { q: "Can you modify or maintain an existing project?", a: "You can ask about an existing project. Share its current setup, the changes you need, and any relevant documentation so feasibility can be reviewed." },
  { q: "Do you provide post-delivery support?", a: "Support and maintenance can be discussed for each project. The agreed delivery scope should clearly state what is included and whether ongoing support is available." },
];

const filters = ["All", "Bots", "Websites", "Applications", "Minecraft", "Launchers", "Hosting"] as const;

function FrostLogo({ small = false }: { small?: boolean }) {
  return (
    <span className={`brand-mark ${small ? "brand-mark-small" : ""}`} aria-hidden="true">
      <Snowflake size={small ? 17 : 20} strokeWidth={1.8} />
    </span>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<(typeof filters)[number]>("All");
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [lightMode, setLightMode] = useState(false);
  const [formStatus, setFormStatus] = useState("");
  const [projectType, setProjectType] = useState("Custom Project");
  const reduceMotion = useReducedMotion();

  const visibleProjects = useMemo(
    () => activeFilter === "All" ? projects : projects.filter((project) => project.category === activeFilter),
    [activeFilter],
  );

  const scrollToContact = (type?: string) => {
    if (type) setProjectType(type);
    setMenuOpen(false);
    document.getElementById("contact")?.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth" });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    const name = String(data.get("name") || "");
    const email = String(data.get("email") || "");
    const type = String(data.get("type") || "Custom Project");
    const title = String(data.get("title") || "");
    const description = String(data.get("description") || "");
    const features = String(data.get("features") || "");
    const budget = String(data.get("budget") || "Not specified");
    const deadline = String(data.get("deadline") || "Not specified");
    const subject = `Project inquiry: ${title || type}`;
    const body = [
      `Name: ${name}`, `Email: ${email}`, `Project type: ${type}`,
      `Project title: ${title || "Not specified"}`, "", "Project description:",
      description, "", `Required features: ${features || "Not specified"}`,
      `Budget: ${budget}`, `Desired deadline: ${deadline}`,
    ].join("\\n");
    const mailto = `mailto:1234.aerix@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setFormStatus("Your email app should open with the inquiry details filled in. Review the message and press Send to deliver it. Nothing has been sent by this website.");
    window.location.href = mailto;
  };

  return (
    <main className={lightMode ? "light-mode" : ""}>
      <div className="nav-shell">
        <nav className="container nav-inner" aria-label="Main navigation">
          <a className="brand" href="#home" aria-label="FrostByteStudios home" onClick={() => setMenuOpen(false)}>
            <FrostLogo />
            <span>FrostByte<span className="gradient-text">Studios</span></span>
          </a>
          <div className={`nav-links ${menuOpen ? "open" : ""}`}>
            {["Home", "About", "Services", "Projects", "Contact"].map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setMenuOpen(false)}>{item}</a>
            ))}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button className="theme-toggle" type="button" aria-label={lightMode ? "Switch to dark mode" : "Switch to light mode"} onClick={() => setLightMode((value) => !value)}>
              {lightMode ? <Moon size={17} /> : <Sun size={17} />}
            </button>
            <button className="btn btn-primary nav-cta" type="button" onClick={() => scrollToContact()}>Start a Project <ArrowRight size={16} /></button>
            <button className="mobile-menu" type="button" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen((value) => !value)}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </nav>
      </div>

      <section className="hero grid-bg" id="home">
        <div className="hero-glow one" /><div className="hero-glow two" />
        <div className="container hero-layout">
          <motion.div initial={reduceMotion ? false : { opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65 }}>
            <div className="eyebrow"><span className="eyebrow-dot" /> Independent developer · India</div>
            <h1><span>Engineering</span><span className="gradient-text">Tomorrow,</span><span>Today.</span></h1>
            <p>Hey, I&apos;m Aerix — an independent developer from India building bots, websites, applications, Minecraft experiences, custom launchers, and hosting infrastructure. Have an idea? Let&apos;s turn it into reality.</p>
            <div className="hero-actions">
              <a className="btn btn-primary" href="#services">Explore My Services <ArrowDownRight size={17} /></a>
              <button className="btn btn-secondary" type="button" onClick={() => scrollToContact()}>Start a Project <ArrowRight size={17} /></button>
            </div>
            <div className="hero-meta">
              <span><MapPin size={15} /> Based in India</span>
              <span><Code2 size={15} /> Built around your idea</span>
            </div>
          </motion.div>
          <motion.div className="hero-art" aria-label="Abstract futuristic developer illustration" initial={reduceMotion ? false : { opacity: 0, scale: .94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .8, delay: .12 }}>
            <div className="orbit a" /><div className="orbit b" /><div className="orbit c" />
            <div className="code-float glass top"><span className="cyan">const</span> vision = <span className="cyan">&quot;build&quot;</span>;<br /><span style={{ color: "#718ba6" }}>// make it real</span></div>
            <div className="core-card glass">
              <div className="core-top"><span>FBS / CORE</span><span>v.01</span></div>
              <div className="core-icon"><Snowflake size={68} strokeWidth={1.1} /></div>
              <h3>Ideas → Reality</h3>
              <p>Creative thinking. Thoughtful engineering.</p>
            </div>
            <div className="code-float glass bottom"><span className="cyan">status</span>: ready_to_build<br /><span style={{ color: "#718ba6" }}>// your next idea starts here</span></div>
          </motion.div>
        </div>
      </section>

      <div className="trust-strip">
        <div className="container trust-inner">
          <div className="trust-item"><Bot size={18} /> Custom-built bots</div>
          <div className="trust-item"><Globe2 size={18} /> Responsive websites</div>
          <div className="trust-item"><TerminalSquare size={18} /> Minecraft solutions</div>
          <div className="trust-item"><ShieldCheck size={18} /> Practical setup & delivery</div>
        </div>
      </div>

      <section className="section" id="about">
        <div className="container about-grid">
          <motion.div className="profile-visual glass" initial={reduceMotion ? false : { opacity: 0, x: -18 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: .2 }}>
            <div className="profile-top"><span>FROSTBYTE / DEVELOPER</span><Sparkles size={18} /></div>
            <div className="profile-monogram">A.</div>
            <div className="profile-bottom"><div><strong>Aerix</strong><small>Founder · FrostByteStudios</small></div><FrostLogo small /></div>
          </motion.div>
          <div>
            <span className="section-kicker">About the developer</span>
            <h2 className="section-title">Meet the Developer <span className="gradient-text">Behind the Code</span></h2>
            <p className="section-copy">I&apos;m Aerix, an independent developer from India and the founder of FrostByteStudios. I enjoy building digital products, creating custom software, developing Minecraft experiences, and setting up hosting environments.</p>
            <p className="section-copy" style={{ marginTop: 14 }}>My goal is to turn creative ideas into practical, well-designed digital solutions. Whether you need a custom bot, website, application, Minecraft server, launcher, or hosting setup, I&apos;m ready to discuss your requirements and explore a suitable solution.</p>
            <p className="section-copy" style={{ marginTop: 14 }}>Have an unusual idea? Tell me about it. Let&apos;s explore what&apos;s possible.</p>
            <div className="skill-pills"><span>Web Development</span><span>Bot Development</span><span>Minecraft</span><span>Hosting Setup</span><span>Custom Projects</span></div>
          </div>
        </div>
      </section>

      <section className="section" id="services" style={{ background: "rgba(255,255,255,.012)" }}>
        <div className="container">
          <span className="section-kicker">Services</span>
          <h2 className="section-title">What I Can <span className="gradient-text">Build For You</span></h2>
          <p className="section-copy">From one focused tool to a bigger custom project, let&apos;s find the right approach for what you have in mind.</p>
          <div className="service-grid">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.article key={service.number} className="service-card glass" initial={reduceMotion ? false : { opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .15 }} transition={{ duration: .35, delay: index * .045 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}><span className="service-icon"><Icon size={22} /></span><span className="service-number">SERVICE / {service.number}</span></div>
                  <h3>{service.title}</h3><p>{service.description}</p>
                  <button className="text-link" type="button" onClick={() => scrollToContact(service.title === "Custom Bots" ? "Bot Development" : service.title === "Website Development" ? "Website Development" : service.title === "Application Development" ? "Application Development" : service.title === "Minecraft Servers" ? "Minecraft Server" : service.title === "Minecraft Launchers" ? "Minecraft Launcher" : "Hosting Setup")}>Discuss Your Project <ArrowRight size={15} /></button>
                </motion.article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 20 }}>
        <div className="container">
          <div className="custom-banner glass">
            <div><span className="section-kicker">Made for your idea</span><h3>Got Something <span className="gradient-text">Different in Mind?</span></h3><p>Not looking for a standard service? Explain your vision, share what you need, and let&apos;s figure out a practical way to build it.</p></div>
            <button className="btn btn-primary" type="button" onClick={() => scrollToContact("Custom Project")}>Let&apos;s Build Something Unique <ArrowRight size={17} /></button>
          </div>
        </div>
      </section>

      <section className="section" id="projects">
        <div className="container">
          <div className="projects-toolbar"><div><span className="section-kicker">Selected concepts</span><h2 className="section-title">Projects & <span className="gradient-text">Experiments</span></h2><p className="section-copy">A portfolio structure ready to grow with real work. Concept labels are used intentionally—replace these entries with verified projects as they become available.</p></div></div>
          <div className="filter-row" aria-label="Filter projects">
            {filters.map((filter) => <button key={filter} type="button" className={`filter-btn ${activeFilter === filter ? "active" : ""}`} aria-pressed={activeFilter === filter} onClick={() => setActiveFilter(filter)}>{filter}</button>)}
          </div>
          <AnimatePresence mode="wait">
            <motion.div key={activeFilter} className="project-grid" initial={reduceMotion ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: .2 }}>
              {visibleProjects.map((project) => {
                const Icon = project.icon;
                return <article className="project-card glass" key={project.name}>
                  <div className="project-cover"><Icon className="project-cover-icon" size={54} strokeWidth={1.3} /></div>
                  <div className="project-body"><div className="project-topline"><span className="project-category">{project.category}</span><span className="status">{project.status}</span></div><h3>{project.name}</h3><p>{project.description}</p><div className="tech-list">{project.technologies.map((tech) => <span key={tech}>{tech}</span>)}</div></div>
                </article>;
              })}
            </motion.div>
          </AnimatePresence>
          <p className="form-note" style={{ marginTop: 17 }}>Portfolio entries above are clearly labeled concepts or work in progress, not claims of completed client work.</p>
        </div>
      </section>

      <section className="section" style={{ background: "rgba(255,255,255,.012)" }}>
        <div className="container">
          <span className="section-kicker">How it works</span><h2 className="section-title">From First Idea to <span className="gradient-text">Final Delivery</span></h2><p className="section-copy">A clear process keeps expectations aligned and makes it easier to build the right thing.</p>
          <div className="process-grid">
            {[{ n: "01", title: "Discover", text: "Understand your idea, requirements, budget, and desired features.", icon: Workflow }, { n: "02", title: "Plan", text: "Choose an appropriate approach, define scope, and map the project structure.", icon: Braces }, { n: "03", title: "Build", text: "Develop, test, refine, and improve the solution against agreed requirements.", icon: Code2 }, { n: "04", title: "Deliver", text: "Provide the agreed deliverables, setup instructions, and support terms.", icon: Check }].map((step, index) => {
              const Icon = step.icon;
              return <motion.article className="process-card glass" key={step.n} initial={reduceMotion ? false : { opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ delay: index * .07 }}><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}><span className="process-number">{step.n}</span><Icon size={20} color="#75e6ff" /></div><h3>{step.title}</h3><p>{step.text}</p></motion.article>;
            })}
          </div>
        </div>
      </section>

      <section className="section" id="faq">
        <div className="container faq-layout">
          <div><span className="section-kicker">FAQ</span><h2 className="section-title">A Few Things <span className="gradient-text">Worth Knowing</span></h2><p className="section-copy">Have another question? Send a message and include any details that can help explain your idea.</p><button className="btn btn-secondary" style={{ marginTop: 24 }} type="button" onClick={() => scrollToContact()}>Ask a Question <ArrowRight size={16} /></button></div>
          <div className="faq-list">
            {faqs.map((faq, index) => <div className="faq-item" key={faq.q}><button className="faq-question" type="button" aria-expanded={openFaq === index} onClick={() => setOpenFaq(openFaq === index ? null : index)}><span>{faq.q}</span><ChevronDown size={18} style={{ transform: openFaq === index ? "rotate(180deg)" : "rotate(0deg)", transition: "transform .2s" }} /></button>{openFaq === index && <div className="faq-answer">{faq.a}</div>}</div>)}
          </div>
        </div>
      </section>

      <section className="section" id="contact" style={{ background: "rgba(255,255,255,.012)" }}>
        <div className="container">
          <span className="section-kicker">Contact</span><h2 className="section-title">Let&apos;s Turn Your Idea <span className="gradient-text">Into Reality</span></h2><p className="section-copy" style={{ marginBottom: 38 }}>Tell me a little about what you want to build. Include only the details you&apos;re comfortable sharing.</p>
          <div className="contact-grid">
            <aside className="contact-info glass">
              <h3>Start a conversation.</h3><p>Have a project in mind, need help choosing a direction, or want to discuss something custom? Reach out by email or use the inquiry form.</p>
              <a className="email-link" href="mailto:1234.aerix@gmail.com"><Mail size={18} /> 1234.aerix@gmail.com <ExternalLink size={14} /></a>
              <div className="contact-detail"><MapPin size={18} /><span><strong>Location</strong><br />India</span></div>
              <div className="contact-detail"><Zap size={18} /><span><strong>Project approach</strong><br />Scope, feasibility, and next steps discussed individually.</span></div>
              <div className="contact-detail"><ShieldCheck size={18} /><span><strong>Clear expectations</strong><br />Pricing and delivery terms are agreed before work begins.</span></div>
            </aside>
            <form className="form-card glass" onSubmit={handleSubmit}>
              {formStatus && <div className="form-status" role="status">{formStatus}</div>}
              <div className="form-grid">
                <div className="field"><label htmlFor="name">Your name *</label><input id="name" name="name" placeholder="How should I address you?" autoComplete="name" required maxLength={100} /></div>
                <div className="field"><label htmlFor="email">Your email *</label><input id="email" name="email" type="email" placeholder="you@example.com" autoComplete="email" required maxLength={200} /></div>
                <div className="field"><label htmlFor="type">Project type *</label><select id="type" name="type" value={projectType} onChange={(event) => setProjectType(event.target.value)} required>{["Bot Development", "Website Development", "Application Development", "Minecraft Server", "Minecraft Launcher", "Hosting Setup", "Custom Project"].map((type) => <option key={type}>{type}</option>)}</select></div>
                <div className="field"><label htmlFor="title">Project title</label><input id="title" name="title" placeholder="A short name for your idea" maxLength={120} /></div>
                <div className="field full"><label htmlFor="description">Project description *</label><textarea id="description" name="description" placeholder="What do you want to build, and what should it do?" required minLength={10} maxLength={5000} /></div>
                <div className="field full"><label htmlFor="features">Required features</label><textarea id="features" name="features" placeholder="List any must-have features, integrations, or platforms." maxLength={3000} style={{ minHeight: 82 }} /></div>
                <div className="field"><label htmlFor="budget">Budget range (optional)</label><select id="budget" name="budget" defaultValue=""><option value="">Prefer to discuss</option><option>Under ₹1,000</option><option>₹1,000–₹5,000</option><option>₹5,000–₹15,000</option><option>₹15,000+</option><option>Not sure yet</option></select></div>
                <div className="field"><label htmlFor="deadline">Desired deadline (optional)</label><input id="deadline" name="deadline" type="date" /></div>
                <div className="field full"><button className="btn btn-primary" type="submit" style={{ width: "100%" }}>Prepare Email Inquiry <Send size={16} /></button></div>
              </div>
              <p className="form-note">This form prepares a message in your email application; it does not send data to a server. Review the draft and press Send in your email app. If nothing opens, email me directly at 1234.aerix@gmail.com.</p>
            </form>
          </div>
        </div>
      </section>

      <footer className="site-footer">
        <div className="container footer-inner">
          <div><a className="brand" href="#home"><FrostLogo /><span>FrostByte<span className="gradient-text">Studios</span></span></a><div className="footer-note" style={{ marginTop: 12 }}>Built with creativity, logic, and a vision for tomorrow.<br />Founder: Aerix · India · <a href="mailto:1234.aerix@gmail.com">1234.aerix@gmail.com</a></div></div>
          <div className="footer-links"><a href="#about">About</a><a href="#services">Services</a><a href="#projects">Projects</a><a href="#faq">FAQ</a><a href="#contact">Contact</a></div>
          <div className="footer-note">© {new Date().getFullYear()} FrostByteStudios.<br />All rights reserved.</div>
        </div>
      </footer>
    </main>
  );
}
