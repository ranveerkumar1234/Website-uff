# FrostByteStudios

A futuristic, responsive developer portfolio for Aerix, built with Next.js App Router, TypeScript, Tailwind CSS v4, Framer Motion, and Lucide icons.

## Requirements

- Node.js 20.9 or newer (LTS recommended)
- npm

## Run locally

1. Extract this folder.
2. Open a terminal in the `frostbytestudios` directory.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the development server:

   ```bash
   npm run dev
   ```

5. Visit http://localhost:3000.

For a production build:

```bash
npm run build
npm start
```

## Included

- Responsive hero, about, services, portfolio, workflow, FAQ, contact, and footer sections
- Mobile navigation
- Light/dark theme toggle
- Animated sections with reduced-motion support
- Portfolio category filters
- Expand/collapse FAQ
- Service CTAs that preselect the relevant project type
- Validated inquiry form that prepares a `mailto:` draft
- SEO metadata and custom SVG favicon

## Contact form behavior

The contact form is intentionally front-end only. On submission it validates the fields and opens the visitor's default email application with a prefilled draft addressed to `1234.aerix@gmail.com`. The website does **not** claim that the message has been delivered; the visitor must review and send the email.

For a server-delivered form, connect a server-side route to a trusted email provider (for example, Resend) or a form backend. Store secrets in server-only environment variables, validate and rate-limit submissions on the server, and never put private API keys in client-side code. `.env.example` is a placeholder for future server-side integration.

## Editing the portfolio

In `src/app/page.tsx`, find the `projects` array near the top. Add or edit entries with:

- `name`
- `category` (`Bots`, `Websites`, `Applications`, `Minecraft`, `Launchers`, or `Hosting`)
- `description`
- `technologies`
- `status` (`Concept`, `In Progress`, or `Completed`)
- `icon` (one of the imported Lucide icons)

Only label work as `Completed` when it is genuinely completed. Current entries are explicitly marked as concepts or work in progress.

## Editing services and FAQs

- Services: edit the `services` array in `src/app/page.tsx`.
- FAQ: edit the `faqs` array in `src/app/page.tsx`.
- Studio details and SEO: edit `src/app/layout.tsx` and the contact/footer content in `src/app/page.tsx`.
- Visual design: edit `src/app/globals.css`.

## Deployment

This project can be deployed to a Next.js-compatible host such as Vercel or a Node.js server.

1. Push the project to a Git repository.
2. Import the repository into your hosting provider.
3. Use `npm run build` as the build command.
4. Use the provider's standard Next.js output/runtime configuration.
5. Add any server-side environment variables only after implementing a backend form endpoint.
6. Connect your own domain and verify metadata, email links, and mobile layouts.

## Pre-launch checklist

- [ ] Run `npm install` and `npm run build`.
- [ ] Test on phone, tablet, and desktop widths.
- [ ] Test mobile navigation, theme toggle, FAQ, and category filters.
- [ ] Submit the contact form and confirm your email application opens with the right details.
- [ ] Replace concept portfolio items with real projects when available.
- [ ] Add a privacy policy and terms page if you implement analytics, data collection, or other relevant features.
- [ ] If you add a server-side form, test validation, spam prevention, and delivery errors.
